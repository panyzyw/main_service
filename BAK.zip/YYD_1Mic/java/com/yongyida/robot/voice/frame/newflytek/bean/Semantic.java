package com.yongyida.robot.voice.frame.newflytek.bean;

/**
 * Created by ruiqianqi on 2016/8/25 0025.
 */
public class Semantic {
    private Slots slots;

    public Slots getSlots() {
        return slots;
    }

    public void setSlots(Slots slots) {
        this.slots = slots;
    }
}
