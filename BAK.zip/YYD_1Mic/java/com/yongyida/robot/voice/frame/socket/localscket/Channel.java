package com.yongyida.robot.voice.frame.socket.localscket;

public interface Channel {
	
	public void sendData();
	
	public void revData();
	
}
