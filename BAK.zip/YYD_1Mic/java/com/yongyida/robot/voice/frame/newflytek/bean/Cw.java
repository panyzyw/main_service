package com.yongyida.robot.voice.frame.newflytek.bean;

/**
 * Created by ruiqianqi on 2016/8/10 0010.
 */
public class Cw {
    private int id;
    private String w;
    private int gm;
    private int sc;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getW() {
        return w;
    }

    public void setW(String w) {
        this.w = w;
    }

    public int getGm() {
        return gm;
    }

    public void setGm(int gm) {
        this.gm = gm;
    }

    public int getSc() {
        return sc;
    }

    public void setSc(int sc) {
        this.sc = sc;
    }
}
