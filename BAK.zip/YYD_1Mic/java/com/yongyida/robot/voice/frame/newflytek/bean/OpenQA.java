package com.yongyida.robot.voice.frame.newflytek.bean;

/**
 * Created by ruiqianqi on 2016/10/13 0013.
 */

public class OpenQA {
    //自增ID
    public long id;
    public String question;
    public String answer;
    public String scene;
    public String thumbnails;
}
