package com.yongyida.robot.voice.frame.newflytek.bean;

import com.yongyida.robot.voice.bean.BaseInfo;

/**
 * Created by ruiqianqi on 2016/8/25 0025.
 */
public class MoveInfo extends BaseInfo {
    private Semantic semantic;

    public Semantic getSemantic() {
        return semantic;
    }

    public void setSemantic(Semantic semantic) {
        this.semantic = semantic;
    }
}
