package com.yongyida.robot.voice.frame.newflytek.bean;

import com.yongyida.robot.voice.bean.BaseInfo;

/**
 * Created by ruiqianqi on 2016/8/26 0026.
 */
public class QuestionInfo extends BaseInfo {
    private Answer answer;

    public Answer getAnswer() {
        return answer;
    }

    public void setAnswer(Answer answer) {
        this.answer = answer;
    }
}
