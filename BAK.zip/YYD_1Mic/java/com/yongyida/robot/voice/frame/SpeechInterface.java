package com.yongyida.robot.voice.frame;



public  interface SpeechInterface {

	public  void start();
	
	public void stop();
	
	void parse();
	
}
