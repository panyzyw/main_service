package com.yongyida.robot.voice.frame.newflytek.bean;

/**
 * Created by ruiqianqi on 2016/8/26 0026.
 */
public class Answer {
    private String type;
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
