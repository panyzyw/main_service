package com.yongyida.robot.voice.bean;

import java.util.Map;

public abstract class CmdInfo {

    protected byte[] byteData;
    protected Map<String, String> dataMap;


}
