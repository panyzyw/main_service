package com.yongyida.robot.voice.data;

import com.yongyida.robot.voice.R;

/**
 * Created by Administrator on 2016/9/20 0020.
 */

public class ImageData {

    public static final int[] Y20_MONITOR_BACKGROUND = {R.raw.listenbg_00, R.raw.listenbg_01
            , R.raw.listenbg_02, R.raw.listenbg_03, R.raw.listenbg_04, R.raw.listenbg_05
            , R.raw.listenbg_06, R.raw.listenbg_07, R.raw.listenbg_08, R.raw.listenbg_09
            , R.raw.listenbg_10, R.raw.listenbg_11, R.raw.listenbg_12, R.raw.listenbg_13
            , R.raw.listenbg_14, R.raw.listenbg_15, R.raw.listenbg_16, R.raw.listenbg_17
            , R.raw.listenbg_18, R.raw.listenbg_19, R.raw.listenbg_20, R.raw.listenbg_21
            , R.raw.listenbg_22, R.raw.listenbg_23, R.raw.listenbg_24, R.raw.listenbg_25
            , R.raw.listenbg_26, R.raw.listenbg_27, R.raw.listenbg_28, R.raw.listenbg_29
            , R.raw.listenbg_30, R.raw.listenbg_31, R.raw.listenbg_32, R.raw.listenbg_33
            , R.raw.listenbg_34, R.raw.listenbg_35, R.raw.listenbg_36, R.raw.listenbg_37
            , R.raw.listenbg_38, R.raw.listenbg_39, R.raw.listenbg_40};

    public static final int[] Y20_MONITOR_MICROPHONE = {R.raw.mai_00, R.raw.mai_01
            , R.raw.mai_02, R.raw.mai_03, R.raw.mai_04, R.raw.mai_05, R.raw.mai_06, R.raw.mai_07
            , R.raw.mai_08, R.raw.mai_09, R.raw.mai_10, R.raw.mai_11, R.raw.mai_12, R.raw.mai_13
            , R.raw.mai_14, R.raw.mai_15, R.raw.mai_16, R.raw.mai_17, R.raw.mai_18, R.raw.mai_19
            , R.raw.mai_20, R.raw.mai_21, R.raw.mai_22, R.raw.mai_23, R.raw.mai_24, R.raw.mai_25
            , R.raw.mai_26, R.raw.mai_27, R.raw.mai_28, R.raw.mai_29, R.raw.mai_30};
}
