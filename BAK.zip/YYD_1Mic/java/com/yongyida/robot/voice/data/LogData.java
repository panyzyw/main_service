package com.yongyida.robot.voice.data;

public class LogData {
	
	public static final String FILE_NAME = "share_data";

	public static final String VERSION_NAME = "version_name";
	
	public static final String URL_ERROR = "url_error";

	public static final String TIMEOUT_ERROR = "timeout_error";

	public static final String CONNECTIONT_ERROR = "connectiont_error";

	public static final String GETINPUTSTREAM_ERROR = "getinputstream_error";

	public static final String GETAPKFILE_ERROR = "getapkfile_error";

	public static final String CLOSESTREAM_ERROR = "closestream_error";

	public static final String COMPARERESULT_ERROR = "compareresult_error";

	public static final String SENDBRC_ERROR = "sendbrc_error";

	public static final String SPEECHSUCCESSPARSE_ERROR = "speechsuccessparse_error";

	public static final String LOGIN_ERROR = "login_error";

	public static final String MOVE_ERROR = "move_error";

	public static final String SOCKETCONNECT_ERROR = "socketconnect_error";

	public static final String PARSESOCKETRESULT_ERROR = "parsesocketresult_error";

	public static final String SENDBROADCAST_ERROR = "sendbroadcast_error";

	public static final String SENDREMIND = "sendremind";

	public static final String PLAYMUSICASSETS = "playmusicassets_error";

	public static final String SENDBROADCASTBIZ = "SendBroadcastBiz_error";
	
}
