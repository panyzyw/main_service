package com.yongyida.robot.voice.subservice;

public interface SubFunctionInterface {

	public void run();
	
	public void stop();
	
}
