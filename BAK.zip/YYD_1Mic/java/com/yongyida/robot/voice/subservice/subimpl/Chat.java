package com.yongyida.robot.voice.subservice.subimpl;

import com.yongyida.robot.voice.subservice.SubFunction;

public class Chat extends SubFunction {

	
	@Override
	public void run() {

	
	}
	
}
